# Chummer6 RunDeck — Complete Redesign From Scratch

**Working title:** Chummer6 RunDeck  
**Primary launch surface:** `chummer6.run`  
**Design stance:** not a dashboard, not an assistant shell, not a productivity app. This is an illegal campaign operations deck for Shadowrun tables.

---

## 0. The Reset

The previous direction was too much "internal tool with cyberpunk words." This redesign starts over.

The product should feel like a fixer handed the GM an illegal operating deck that turns table chatter, player requests, feature feedback, campaign prep, run reports, contacts, heat, and release notes into one living system.

**New center of gravity:** ProductLift.dev Tier 5 becomes the public signal and roadmap spine.

ProductLift is not a footer link. It becomes the **Fixer Board**: the place where players, GMs, testers, and maintainers submit field reports, vote on priorities, watch the roadmap, read shipped changes, and get notified when something they backed is installed.

---

## 1. ProductLift.dev Tier 5: What It Becomes

### ProductLift public name inside Chummer6

# **Fixer Board**

### ProductLift role

ProductLift powers the public product loop:

1. **Field Reports** — feedback board / feature requests / bug reports / usability complaints.
2. **Contracts** — public roadmap with custom statuses and voting.
3. **Patch Notes from the Sprawl** — changelog and shipped-feature announcements.
4. **Black Book** — knowledge base / help articles generated from shipped features.
5. **Voter notifications** — users who voted get notified when status changes or when a feature ships.
6. **Embedded widgets** — feedback capture and "what's new" directly inside the Chummer6 app.
7. **Custom branding / SCSS / domain** — the ProductLift portal should look native to `chummer6.run`.
8. **API + webhooks** — feed signals into the Executive Assistant design lanes and release pipeline.

### Why this is better

Chummer6 is not only a tool. It is an evolving public product. ProductLift should make users feel that their table problems are entering a visible queue and coming back as shipped improvements.

The Fixer Board closes the trust loop:

> report → vote → triage → roadmap → build → ship → notify → document

---

## 2. ProductLift Configuration Spec

### Portal domain

Preferred:

```text
fixer.chummer6.run
```

Acceptable alternatives:

```text
feedback.chummer6.run
roadmap.chummer6.run
```

Recommendation: use **`fixer.chummer6.run`** because it has Shadowrun flavor but still makes sense in navigation.

---

## 3. ProductLift Boards / Tabs

### 3.1 Field Reports

Public board for new ideas, bug reports, pain points, feature requests, and UX complaints.

**ProductLift module:** Feedback Board  
**UI label:** Field Reports  
**CTA:** Submit Field Report

Post types:

- Feature Request
- Bug / Glitch
- UX Friction
- Import Problem
- Campaign Ops Request
- GM Workflow Request
- Player-Facing Request
- Visual / Scene Request
- Mobile / Offline Request
- Integration Request

### 3.2 Contracts

The public roadmap. Items move from vague signal to accepted work.

**ProductLift module:** Product Roadmap  
**UI label:** Contracts  
**CTA:** View Open Contracts

Columns:

1. **Signal Intake** — visible but not committed.
2. **Under Legwork** — being researched / scoped.
3. **Accepted Contract** — committed to roadmap.
4. **In the Shop** — actively building.
5. **Field Test** — beta / QA / limited release.
6. **Installed** — shipped.
7. **Archived / Burned** — declined, merged, or no longer relevant.

### 3.3 Patch Notes from the Sprawl

The public changelog.

**ProductLift module:** Changelog  
**UI label:** Patch Notes  
**CTA:** See What Shipped

Entry types:

- Added
- Fixed
- Improved
- Balanced
- Imported
- Visual Update
- Campaign Ops Update
- Security / Privacy
- Known Issue

### 3.4 Black Book

Product docs, help articles, feature explainers, quick-starts, and GM/player guides.

**ProductLift module:** Knowledge Base  
**UI label:** Black Book  
**CTA:** Open the Black Book

Topics:

- Getting Started
- Character Import
- Campaign Ops
- GM Tools
- Player View
- Heat / Contacts / Runs
- Scene Forge
- Fixer Board
- Troubleshooting
- Release Notes

### 3.5 Private Ops

Internal/private ProductLift board for maintainers and testers.

**Visibility:** private / restricted  
**Purpose:** not everything belongs on the public board. Use this for implementation notes, exploit/security issues, internal strategy, and non-public roadmap items.

---

## 4. ProductLift Categories

Use categories that sound like the actual product, not generic SaaS.

| Category | Description |
|---|---|
| Character Builder | Character creation, import, sheets, validation, gear, skills, magic, cyberware. |
| Campaign Ops | Briefs, aftermath, session continuity, downtime, active run state. |
| GM Control | GM-only notes, opposition packets, secrets, encounter prep. |
| Player View | Player-safe summaries, recaps, handouts, downtime choices. |
| Contact Matrix | NPCs, factions, favors, relationship temperature, obligations. |
| Heat Monitor | Consequences, law/corp/gang pressure, escalation clocks. |
| Scene Forge | Visuals, scene packets, handouts, media generation, location boards. |
| Imports & Sync | Chummer data import, export, versioning, external integrations. |
| Mobile / Offline | Field cache, offline continuity, phone view, travel mode. |
| Rules & Canon | Rule interpretation, edition support, validation, house rules. |
| Accessibility | Readability, keyboard flow, color contrast, low-glare UI. |
| Performance | Speed, large character files, campaign size, sync reliability. |

---

## 5. ProductLift Status Language

Use custom statuses so the portal feels native.

| ProductLift Status | Public Label | Meaning |
|---|---|---|
| New | Signal Intake | User-submitted and visible. |
| Reviewing | Under Legwork | Researching, merging duplicates, asking questions. |
| Planned | Accepted Contract | Committed to roadmap. |
| In Progress | In the Shop | Build underway. |
| Beta | Field Test | Test release / limited rollout. |
| Shipped | Installed | Live and announced. |
| Duplicate | Merged Signal | Merged into another report. |
| Declined | Burned | Not pursuing; reason required. |

Every declined or archived item needs a visible reason. Trust depends on this.

---

## 6. ProductLift Voting Model

Voting should feel like table demand, not generic SaaS voting.

### Public labels

- Vote button: **Back This Contract**
- Vote count: **Backers**
- Comment box: **Add Field Note**
- Submit button: **Send to Fixer**

### Vote metadata to capture

If possible via SSO, hidden fields, user segmentation, or webhook enrichment:

- Role: GM / Player / Builder / Tester / Maintainer
- Table size
- Campaign mode: one-shot / campaign / living campaign / offline travel / convention
- Edition / ruleset context
- OS / browser / device
- Character import source
- Pain severity: annoyance / blocker / table-stopper
- Visibility impact: public-player-facing / GM-only / internal

---

## 7. ProductLift Prioritization Rubric

Use ProductLift's AI prioritization and built-in frameworks, but rename the internal scoring to fit Chummer6.

## **Run Impact Score**

```text
Run Impact Score =
  30% table pain severity
+ 20% vote / backer count
+ 15% GM impact
+ 15% player impact
+ 10% implementation confidence
+ 10% strategic fit with RunDeck
```

### Priority labels

| Score | Label | Meaning |
|---|---|---|
| 90–100 | Prime Contract | Build now or schedule immediately. |
| 75–89 | Hot Signal | Strong candidate for next sprint. |
| 55–74 | Useful Lead | Keep visible, needs more data. |
| 35–54 | Cold Case | Low urgency or unclear scope. |
| 0–34 | Burned Trail | Decline, merge, or archive. |

### Internal ProductLift workflow

1. AI clusters duplicate / similar reports.
2. Maintainer merges duplicates and preserves votes.
3. AI scores against the product vision.
4. Human owner assigns category, effort, and visibility.
5. Item enters roadmap if it supports the RunDeck direction.
6. When shipped, item becomes changelog + optional KB article.

---

## 8. ProductLift Embeds Inside Chummer6

### 8.1 In-app feedback widget

Placement:

- persistent bottom-right button in authenticated app
- label: **Send Field Report**
- icon: dossier + signal flare

Widget fields:

- What happened?
- What were you trying to do?
- GM or player view?
- Character / campaign affected?
- Screenshot or file attachment
- Severity
- Suggested fix

### 8.2 Roadmap sidebar embed

Placement:

- `/fixer-board`
- right rail in app settings
- landing-page section

Display:

- top accepted contracts
- in-shop items
- field-test items
- recently installed features

### 8.3 What's New widget

Placement:

- app header pulse
- player view welcome screen
- GM dashboard after login

Label:

> **New Ware Installed**

### 8.4 Knowledge base embed

Placement:

- `/black-book`
- help menu
- context help drawer on complex screens

Label:

> **Open Black Book**

---

## 9. API / Webhook Integration Plan

ProductLift currently sits in the LTD inventory as credential-captured but not actively wired. This redesign promotes it by giving it a concrete event route.

### Events to wire

Use exact ProductLift webhook event names when confirmed in the ProductLift admin/API docs. The intended mapping is:

| ProductLift signal | Chummer6 / EA destination | Purpose |
|---|---|---|
| New post | `design_synthesis` | Cluster repeated findings and summarize product signal. |
| New vote | product signal ledger | Update backer weight and priority score. |
| New comment | `design_petition` or triage queue | Capture richer context and objections. |
| Status changed | roadmap projection | Keep public and internal state aligned. |
| Shipped item | changelog + Emailit dispatch | Notify voters and optionally send release digest. |
| KB article generated | docs freshness lane | Keep help docs aligned with release state. |

### Data stored locally

Do not make ProductLift the core app database. Store mirrored signal records only:

- ProductLift post ID
- public title
- status
- category
- backer count
- priority score
- linked repo issue / task
- linked changelog entry
- shipped timestamp
- source URL

ProductLift owns public feedback UX. The local app owns runtime truth.

---

## 10. Complete Page Redesign

## 10.1 New product position

# **Chummer6 RunDeck**

### Hero claim

> **Run the shadows. Build the product with the crew.**

### Secondary claim

> Chummer6 RunDeck turns campaign prep, character data, table feedback, roadmap votes, and release notes into one living Shadowrun command surface.

This is a better promise than only saying "campaign dashboard." It makes the public product loop part of the identity.

---

## 10.2 Public site navigation

Desktop nav:

- RunDeck
- Campaign Ops
- Character Ops
- Fixer Board
- Patch Notes
- Black Book
- Open App

Mobile nav:

- RunDeck
- Fixer Board
- Patch Notes
- App

---

## 10.3 Hero section

### Visual

A widescreen illegal deck UI:

- left: headline and CTAs
- center: active run dossier
- right: Fixer Board signal cards
- bottom: live signal strip showing heat, contracts, changelog, and field reports

### Copy

```text
YOUR CAMPAIGN IS NOT A SPREADSHEET.
IT IS AN OPERATION.

Chummer6 RunDeck gives Shadowrun tables a living command surface for characters, contacts, heat, runs, opposition, feedback, roadmap contracts, and shipped upgrades.
```

### CTAs

Primary:

```text
Open RunDeck
```

Secondary:

```text
Back a Contract
```

Tertiary:

```text
Read Patch Notes
```

---

## 10.4 Section: The Active Run

Purpose: prove this is a GM/player tool, not a corporate productivity wrapper.

Cards:

- Objective
- Crew
- Known Threats
- Contact Pressure
- Heat Level
- Next Scene
- Player-Safe Brief
- GM-Only Secrets

Copy:

> Every run has a brief, a crew, a clock, and consequences. RunDeck keeps those parts alive before, during, and after the session.

---

## 10.5 Section: Fixer Board

This is the flagship ProductLift section.

### Visual

A public feedback/roadmap board styled as neon contract cards:

- **Field Reports** column
- **Under Legwork** column
- **In the Shop** column
- **Installed** column

Sample cards:

1. **Better contact relationship map**  
   Category: Contact Matrix  
   Backers: 84  
   Status: In the Shop

2. **Player-safe aftermath summaries**  
   Category: Campaign Ops  
   Backers: 57  
   Status: Field Test

3. **Import cyberware notes without losing custom text**  
   Category: Character Builder  
   Backers: 112  
   Status: Under Legwork

4. **Mobile downtime packet**  
   Category: Mobile / Offline  
   Backers: 39  
   Status: Accepted Contract

### Copy

> The Fixer Board is where table pain becomes product direction. Submit field reports, back open contracts, watch the roadmap, and get notified when your requested feature ships.

### CTAs

- Submit Field Report
- View Open Contracts
- See Installed Upgrades

---

## 10.6 Section: Character Ops

Purpose: keep Chummer identity.

Cards:

- Character file import
- Build validation
- Gear/cyberware/magic notes
- Player-safe summaries
- rule/canon flags
- character-to-campaign continuity

Copy:

> Characters are not static sheets. They carry debts, ware, contacts, scars, favors, secrets, and decisions. Character Ops makes those matter at the table.

---

## 10.7 Section: Contact Matrix + Heat Monitor

Purpose: make campaign memory visceral.

Visual:

A side-by-side faction map and heat meter.

Contact Matrix fields:

- name
- role
- faction
- relationship temperature
- owed favors
- last scene
- player-safe / GM-only toggle

Heat Monitor fields:

- corp attention
- gang pressure
- law enforcement
- matrix exposure
- astral disturbance
- next escalation

Copy:

> The sixth world remembers. Favors age. Heat rises. Contacts get nervous. Corps adapt.

---

## 10.8 Section: Scene Forge

Purpose: make the product feel flagship.

Do not use generic cyberpunk wallpaper. Each scene card must have playable information.

Scene card contents:

- scene title
- location function
- faction presence
- threat clue
- usable prop
- player decision cue
- GM-only secret
- visual prompt / media brief

Copy:

> Scene Forge turns locations into playable packets: mood, clues, props, threats, and player-facing handouts.

---

## 10.9 Section: Patch Notes from the Sprawl

ProductLift changelog as a premium public feature.

Visual:

A timeline of shipped upgrades:

- Installed: Contact Matrix relationship temperatures
- Fixed: custom notes lost during import
- Improved: GM-only/player-safe summary split
- Added: Field Report widget inside RunDeck

Copy:

> When a backed contract ships, the crew hears about it. Patch Notes from the Sprawl keeps the product visibly alive.

---

## 10.10 Section: Black Book

ProductLift knowledge base as in-world documentation.

Visual:

Searchable tactical manual.

Topics:

- Start a Campaign
- Import a Character
- Read Heat
- Use Contacts
- Submit Field Reports
- Track Patch Notes
- GM-only vs Player-safe Data

Copy:

> The Black Book documents what shipped, how to use it, and what changed.

---

## 11. Authenticated App Redesign

## 11.1 Layout

Three-zone app shell:

1. **Left rail:** persistent navigation.
2. **Center deck:** the active campaign/run object.
3. **Right rail:** live signal, heat, approvals, ProductLift contracts, latest shipped changes.

### Left rail

- Active Run
- Characters
- Crew
- Contacts
- Heat
- Opposition
- Scene Forge
- Dispatch
- Fixer Board
- Black Book
- Settings

### Center deck default

**Active Run Card**

- Run name
- phase
- crew
- objective
- clock
- next decision
- open secrets
- player-safe summary

### Right rail

**Live Signals**

- Heat: Rising
- New Field Reports: 6
- Backed Contract: Contact Matrix v2
- Latest Install: player-safe recap split
- Pending GM Review: 2

---

## 12. Visual Design System

## 12.1 Design principles

1. **Cinematic, but legible.** No fake hacker soup.
2. **World language on top, plain explanation underneath.**
3. **Every panel has a job.** No decorative stats that do not drive action.
4. **Player-safe and GM-only states are always visible.**
5. **ProductLift surfaces must look native.** Use custom domain, theme, and SCSS.

## 12.2 Color tokens

```css
--void: #05070b;
--carbon: #0b1018;
--glass: rgba(13, 20, 31, 0.72);
--line: rgba(117, 251, 221, 0.20);
--text: #f3f7f5;
--muted: #8fa3a0;
--matrix: #5cffc6;
--cyan: #55d8ff;
--amber: #ffca58;
--danger: #ff4b5f;
--astral: #a77cff;
```

## 12.3 Type

- Display: condensed grotesk, uppercase, tight tracking.
- Body: clean sans, readable at small sizes.
- System: monospace for packet IDs, timestamps, status tags.

## 12.4 Components

### Contract Card

Used for ProductLift posts and roadmap items.

Fields:

- title
- category
- status
- backers
- priority score
- last movement
- CTA: Back This Contract

### Field Report Card

Fields:

- issue / request
- affected surface
- severity
- role: GM/player
- comments
- merged duplicates

### Run Dossier

Fields:

- objective
- clock
- crew
- NPCs
- scene
- heat
- secrets
- next move

### Patch Note Card

Fields:

- status: installed / fixed / improved
- shipped date
- linked contract
- voter notification status
- KB article link

---

## 13. Microcopy

### Generic → Chummer6

| Generic | Chummer6 |
|---|---|
| Submit feedback | Send Field Report |
| Vote | Back This Contract |
| Roadmap | Open Contracts |
| Changelog | Patch Notes from the Sprawl |
| Knowledge Base | Black Book |
| Feature shipped | New Ware Installed |
| Bug | Glitch |
| Reviewing | Under Legwork |
| Planned | Accepted Contract |
| In Progress | In the Shop |
| Beta | Field Test |
| Completed | Installed |
| Declined | Burned |

---

## 14. Homepage Wireframe

```text
[Top Nav]
Chummer6 RunDeck | RunDeck | Campaign Ops | Fixer Board | Patch Notes | Black Book | Open App

[Hero]
Left: headline + copy + CTAs
Center: Active Run Dossier
Right: Fixer Board live signal cards
Bottom: status strip

[Active Run]
Campaign operation overview

[Fixer Board]
ProductLift feedback + roadmap + changelog journey

[Character Ops]
Character sheet and campaign continuity

[Contact Matrix / Heat Monitor]
World memory and consequences

[Scene Forge]
Playable visual/location packets

[Patch Notes]
ProductLift changelog

[Black Book]
ProductLift knowledge base

[CTA]
Open RunDeck / Back a Contract
```

---

## 15. MVP Implementation Plan

## Phase 1 — ProductLift becomes visible

- Set up custom domain: `fixer.chummer6.run`.
- Configure ProductLift theme and custom labels.
- Create Field Reports board.
- Create Contracts roadmap columns.
- Create Patch Notes changelog categories.
- Create Black Book top-level topics.
- Add in-app feedback widget.
- Add What's New widget.
- Add homepage Fixer Board section.

## Phase 2 — ProductLift becomes operational

- Add SSO or authenticated user context.
- Add user segments: GM, Player, Builder, Tester, Maintainer.
- Add categories and statuses listed above.
- Wire API/webhooks into local signal mirror.
- Route repeated signals to `design_synthesis`.
- Route major design changes to `design_petition`.
- Mirror shipped changelog into release surface.

## Phase 3 — ProductLift closes the loop

- Voters notified when items move.
- Changelog entries trigger release digest.
- Shipped items generate Black Book article drafts.
- Patch Notes surface appears in app.
- Public roadmap becomes part of the landing page.

## Phase 4 — ProductLift becomes strategic

- Use prioritization frameworks.
- Use AI scoring against product vision.
- Add internal/private board for maintainer work.
- Add score dashboards for Run Impact Score.
- Use ProductLift data as roadmap input, not random GitHub issue noise.

---

## 16. Product Vision for ProductLift AI

Use this as the ProductLift product vision seed:

```text
Chummer6 RunDeck helps Shadowrun players and GMs manage characters, campaigns, contacts, heat, runs, opposition, recaps, and table continuity without turning play into administrative work. Prioritize features that make the table faster, more cinematic, more reliable, and easier to continue across sessions. Favor GM/player-facing value, character import integrity, campaign continuity, player-safe summaries, and trustworthy public feedback loops. Avoid features that turn the product into a generic productivity dashboard or hide user-facing value behind internal tooling.
```

---

## 17. Launch Copy

### Hero

```text
Run the shadows. Build the product with the crew.

Chummer6 RunDeck gives Shadowrun tables a living command surface for characters, contacts, heat, runs, opposition, field reports, roadmap contracts, and shipped upgrades.
```

### Fixer Board

```text
The Fixer Board turns table pain into product direction. Submit field reports, back open contracts, watch the roadmap, and get notified when your requested feature ships.
```

### Patch Notes

```text
When new ware is installed, the crew hears about it. Patch Notes from the Sprawl keeps every shipped feature tied to the field reports that asked for it.
```

### Black Book

```text
The Black Book documents how the deck works, what changed, and how to get your table moving again.
```

---

## 18. What Makes This Redesign Less Ugly

1. ProductLift is no longer an add-on. It is a named product surface.
2. The page has a real user loop: submit → vote → roadmap → ship → notify → document.
3. The UI has a visual concept: illegal operations deck, not dashboard.
4. The IA is grounded in table use: characters, runs, contacts, heat, scenes, dispatch.
5. The language is flavored but still understandable.
6. The authenticated app and public page share one system.
7. The roadmap becomes a trust feature, not a project management afterthought.

---

## 19. Files in this redesign package

- `chummer6-run-redesign.html` — static visual prototype.
- `chummer6-redesign.md` — this complete design guide.
- `productlift-fixer-board-config.json` — implementation-oriented configuration spec.
